public abstract class PaymentService {
    public abstract String getPaymentStatus();
    public abstract String getPaymentMethod();
}

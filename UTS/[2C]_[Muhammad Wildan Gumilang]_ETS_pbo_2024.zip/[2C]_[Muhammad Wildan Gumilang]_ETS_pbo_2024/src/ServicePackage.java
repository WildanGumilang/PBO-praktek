public class ServicePackage {
    private String service;
    private int value;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
